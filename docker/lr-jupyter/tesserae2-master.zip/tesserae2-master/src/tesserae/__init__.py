# Set our version:
__version__ = "1.2.1"

# Import our tesserae class for easy access and tell flake8 checks to ignore it:
from .model import Tesserae  # noqa: F401
