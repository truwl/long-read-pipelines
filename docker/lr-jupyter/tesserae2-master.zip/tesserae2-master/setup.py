from io import open

from setuptools import find_packages, setup

# following src dir layout according to
# https://blog.ionelmc.ro/2014/05/25/python-packaging/#the-structure
version = "1.2.1"
setup(
    name="tesserae",
    version=version,
    description="Fast recombination-aware global and local alignment",
    author="Warren W. Kretzschmar, Kiran V Garimella",
    author_email="winni@warrenwk.com, kiran.garimella@gmail.com",
    license="Apache-2.0",
    long_description=open("README.rst").read(),
    install_requires="""
    numpy
    pysam
    dataclasses
    """.split(
        "\n"
    ),
    tests_require=["coverage", "pytest"],
    python_requires=">=3.6",
    packages=find_packages("src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: Apache Software License",
        "Natural Language :: English",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: Implementation :: CPython",
    ],
    entry_points={"console_scripts": ["tesserae=tesserae.__main__:main_entry"]},
    include_package_data=True,
)
